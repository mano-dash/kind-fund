const env = {
  isProduction: process.env.NODE_ENV === "production",
  API_BASE: process.env.REACT_APP_API_BASE,
};

export default env;
