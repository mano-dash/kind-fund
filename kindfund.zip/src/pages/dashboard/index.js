
import React from "react";
import AppHeader from "../../components/shared/header";
import AppFooter from "../../components/shared/footer";
// import ProductBody from "../../components/featured/product";

class Product extends React.Component {
  render() {
    return (
      <div>
        <AppHeader/>
        {/* <ProductBody /> */}
        <h1>Dashboard Page</h1>
        <AppFooter />
      </div>
    );
  }
}
export default Product;




// const DashboardPage = (props) => <h1>Dashboard Page</h1>;

// DashboardPage.propTypes = {};

// export default DashboardPage;
