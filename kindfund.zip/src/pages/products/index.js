const ProductsPage = (props) => <h1>Products Page</h1>;

ProductsPage.propTypes = {};

export default ProductsPage;
