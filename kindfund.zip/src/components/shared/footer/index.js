const Footer = () => <footer>Footer Area</footer>;
export default Footer;
