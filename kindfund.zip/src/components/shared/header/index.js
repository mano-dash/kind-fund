const Header = () => <header>Header</header>;
export default Header;
